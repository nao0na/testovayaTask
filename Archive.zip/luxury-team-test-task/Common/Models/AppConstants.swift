enum AppConstants {

    static let appName = "Luxury Stocks"
    static let termsAndPrivacyURL = ""
    static let email = ""
    static let appId = ""
    static let appReviewLink = ""
    static let twitterLink = ""
    static let instagramLink = ""
    static let supportURL = ""

}
