protocol RootViewModelCoordinatorDelegate: BaseViewModelCoordinatorDelegate {

    func startMainFlow()

}
